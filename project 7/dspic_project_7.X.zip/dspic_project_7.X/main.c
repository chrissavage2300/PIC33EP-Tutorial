/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.169.0
        Device            :  dsPIC33EP32MC202
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.50
        MPLAB 	          :  MPLAB X v5.40
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/mcc.h"    //NOTE HAD TO ADD THIS.
#include <libpic30.h>
#include <stdio.h>

/*
                         Main application
 * This is a test of the encoder module
 * QA=RB10, Pin 21 RP42
 * QB=RB11, Pin 22 RP43
 * QI=RB12, Pin 23 RP44 INDEX IS ENABELED. Active low. Have resistor set high
 * QH=RB13, Pin 24 RP45
 * QEI1 Phase A(3) QEA1 RPINR14 QEA1R[6:0]
 * QEI1 Phase B(3) QEB1 RPINR14 QEB1R[6:0]
 * 
 */
int main(void)

{
void lockMapping (void)
    {
    __builtin_write_OSCCONL (OSCCON | (1<<6));
    }

void unlockMapping (void)
    {   // unlock mapping function for editing
    __builtin_write_OSCCONL (OSCCON & ~(1<<6));
    }
void EncoderMap(void)
    {
    unlockMapping();
    RPINR14bits.QEA1R=0b0101010;
    RPINR14bits.QEB1R=0b0101011;
    RPINR15bits.INDX1R=0b0101100;
    RPINR15bits.HOME1R=0b0101101;
    lockMapping();

    }
    
    
 void EncoderInterface (void)
 {
               
            QEI1CONbits.QEISIDL = 0x00;         // Module operational in idle mode
            QEI1CONbits.PIMOD = 0x01;           // Index resets position.
            QEI1CONbits.IMV = 0x00;             // Index match QEB = 0 & QEB = 1                                               
            QEI1CONbits.INTDIV = 0x00;          // Prescale 1:1
            QEI1CONbits.CNTPOL = 0x00;          // Positive count
            QEI1CONbits.GATEN = 0x00;           // External gate does not effect position
            QEI1CONbits.CCM = 0x00;             // Mode: quadrature
            QEI1IOCbits.QCAPEN = 0x00;          // Home triggers capture event              
            QEI1IOCbits.FLTREN = 0x01;          // Digital filter on
            QEI1IOCbits.QFDIV = 0x01;           // 1:1 digital filter clock divide
            QEI1IOCbits.OUTFNC = 0x00;          // Output function disabled
            QEI1IOCbits.SWPAB = 0x0;           // Swap QEA and QEB no
            QEI1IOCbits.HOMPOL= 0x0;          //no home inversion
            QEI1IOCbits.IDXPOL = 0x0;          // No Input inversion
            QEI1IOCbits.QEBPOL = 0x0;          // No QEB1 inversion
            QEI1IOCbits.QEAPOL = 0x0;          // No QEA1 inversion
            QEI1STATbits.PCHEQIEN = 0x00;       // Position counter > = int disabled                                                               // Enabled
            QEI1STATbits.PCLEQIEN = 0x00;       // Position counter < = int disabled
            QEI1STATbits.POSOVIEN = 0x00;       // Position counter overf int disabled
            QEI1STATbits.PCIIEN = 0x00;         // Position counter homing int disabled
            QEI1STATbits.VELOVIEN = 0x00;       // Velocity counter overf int disabled
            QEI1STATbits.HOMIEN = 0x00;         // Home input event int disabled
            QEI1STATbits.IDXIEN = 0x00;         // Index input event int disabled
            QEI1CONbits.QEIEN = 0x01;           // Enable QEI module    

    
        
    }

 
    signed int qeiPosition;
    
    qeiPosition= 0x00;
    

    // initialize the device
    SYSTEM_Initialize();
    EncoderMap();
    EncoderInterface();
   
    while (1)
    {
        qeiPosition= POS1CNTL;
     
        



        // Add your application code
    }
    return 1; 
}
/**
 End of File
*/

