/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.169.0
        Device            :  dsPIC33EP32MC202
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.50
        MPLAB 	          :  MPLAB X v5.40
 * 
 * 
 * struct
{
    unsigned int M1 : 1; 
    unsigned int M2 : 1;
    unsigned int M3 : 1; 
    unsigned int M4 : 1; 
}Mtotal;

int main()
{
    Mtotal.M1=1;
    Mtotal.M2=1;
    Mtotal.M3=0;
    Mtotal.M4=1;
    printf("Hello World\n");
    printf("Mtotal:%d\nM1:%d\nM2:%d\nM3:%d\nM4:%d\n",Mtotal,Mtotal.M1,Mtotal.M2,Mtotal.M3,Mtotal.M4);
    return 0;
*/

/*

*/
#define FCY 7370000UL
/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/mcc.h"    //NOTE HAD TO ADD THIS.
#include <libpic30.h>
#include <stdio.h>

/*
                         Main application
 * This program interfaces to the MCP4911 SPI DAC
 */


int main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    SPI1_Initialize();

union DAC_DATA_UNION
{
    struct  
    { //The first bit defined will be the LSb of the word in which it will be stored.            
        unsigned DAC_NODATA:2;
        unsigned DAC_Data:10;
        
        unsigned DAC_SHDN:1;
        unsigned DAC_GAIN:1;
        
        unsigned DAC_Buffer:1;
        unsigned DAC_WRITE:1;
        
        
        }DAC;
  unsigned int DAC_PLACEHOLDER;     
};

union DAC_DATA_UNION DAC;
        
    void DAC_Init_Commands(void){
    DAC.DAC.DAC_NODATA=0;    
    DAC.DAC.DAC_WRITE=0;    
    DAC.DAC.DAC_Buffer=1;//Buffer on
    DAC.DAC.DAC_GAIN=1;//Gain = 1x
    DAC.DAC.DAC_SHDN=1;//active mode
    DAC.DAC.DAC_Data=8;
    }     
    
        
    
    DAC_Init_Commands();
    unsigned int DAC_WHOLE= DAC.DAC_PLACEHOLDER;
   
    while (1)
    {   
        
        
       
        CS_SetLow();
        //SPI_REC_DATA=SPI1_Exchange16bit(DAC_WHOLE);
        SPI1_Exchange16bit(DAC_WHOLE);
        CS_SetHigh();
        
        
        // Add your application code
    }
    return 1; 
}
/**
 End of File
*/

