/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.169.0
        Device            :  dsPIC33EP32MC202
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.50
        MPLAB 	          :  MPLAB X v5.40
*/

/*
 * This program takes an ADC reading from PORT A0 and then sends it out
 * via UART.
*/
#define FCY 7370000UL
/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/mcc.h"    //NOTE HAD TO ADD THIS.
#include <libpic30.h>
#include <stdio.h>

/*
                         Main application
 */
int main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    UART1_Initialize();
    unsigned short conversion,i=0;
    
    ADC1_Initialize();
    ADC1_Enable();
    while (1)
    {
        ADC1_ChannelSelect(POT);
                //Provide Delay
        for(i=0;i <1000;i++)
        {
        }      
        while(!ADC1_IsConversionComplete(POT));
        conversion = ADC1_ConversionResultGet(POT);
        __delay_ms(100);
        //printf("Conversion Complete \r\n");
        //Note: need %d in order to show numbers. the %d format specifer
        //is used to denotate an integer.
        printf("POT:= %d\r\n", conversion);
        
        
        
        // Add your application code
    }
    return 1; 
}
/**
 End of File
*/

