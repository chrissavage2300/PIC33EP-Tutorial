/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.170.0
        Device            :  dsPIC33EP32MC202
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.61
        MPLAB 	          :  MPLAB X v5.45
*/

/*
 * TX goes to RX on Nextion
 * RX goes to TX on Nextion
*/
#define FCY 7370000UL

/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/mcc.h"    //NOTE HAD TO ADD THIS.
#include <libpic30.h>
#include <stdio.h>
#include <string.h>

/*
                         Main application
 */
int main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    UART1_Initialize();
    // buffer for UART
    char buf[16];
    
    void touchscreen_command(char* string);
    void button0_function(char* buf);
    void button1_function(char* buf);
    unsigned int i;

    i=1043;

    while (1)

    {
        // Add your application code
        touchscreen_command("t0.txt=\"Hello world 123456789ABCDEF\"");


        printf("n0.val=");
        printf("%d", i);
        UART1_Write(0xFF);
        UART1_Write(0xFF);
        UART1_Write(0xFF);    
        EUSART_Read_Text(buf, 11);
   
 /*When making buttons on Nextion, be sure to use the "print" function        
 * Had to set code on button to "print "Button0" in order for it to work
 */
        
        button0_function(buf);
        button1_function(buf);
     
    }
    return 1; 
}
void touchscreen_command(char* string)
{
    printf(string);
    UART1_Write(0xFF);
    UART1_Write(0xFF);
    UART1_Write(0xFF);
    //__delay_ms(1000);
    
}

void EUSART_Read_Text(char *Output, unsigned int length)
{
	int j;
	for(j=0;j<length;j++)
	Output[j] = UART1_Read();
}

void button0_function(char* buf)//note: had to set HMI button to print this string
{
    char* button0;//this is a pointer
    button0=strstr(buf,"Button0");
       if (button0 == NULL)
   {
       return;
   }
       else{
        RB5_LED_Toggle();
       }
    
}


void button1_function(char* buf)//note: had to set HMI button to print this string
{
    char* button1;//this is a pointer
    button1=strstr(buf,"REDLED");
       if (button1 == NULL)
   {
       return;
   }
       else{
        RA4_LED_Toggle();
       }
    
}



/**
 End of File
*/

